import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

//Claudia Rush
public class KBDriver {
	static boolean entails = false;
	static List<String> proof = new ArrayList<>();
	static String resolvedLiteral = "";
	
	private static class KnowledgeBase{
		private Set<Clause> clauses;
		
		private KnowledgeBase() {
			clauses = new HashSet<Clause>();
		}
		
		private Clause parseClause(String clauseString) {
			String[] literalStrings = clauseString.split(" v ");
	        Clause clause = new Clause();

	        for (String literalString : literalStrings) {
	            Literal literal = parseLiteral(literalString);
	            clause.addLiteral(literal);
	        }

	        return clause;
		}
		private Literal parseLiteral(String literalString) {
	        boolean negated = literalString.startsWith("~");
	        String symbol = "";
	        if(negated) {
	        	symbol = literalString.substring(1);
	        }
	        else {
	        	symbol = literalString;
	        }
	        return new Literal(symbol, negated);
	    }
		
		private void addClause(String clauseString) {
			Clause clause = parseClause(clauseString);
			clauses.add(clause);
		}
		
	}
	
	private static class Literal{
		private String symbol;
		private boolean negated;
		
		private Literal(String symbol, boolean negated) {
			this.symbol = symbol;
			this.negated = negated;
		}
		
		public Literal simplify() { //helper method to remove unnecessary negations from clauses
	        String simplifiedSymbol = symbol;

	        while (simplifiedSymbol.startsWith("~")) {
	            negated = !negated;
	            simplifiedSymbol = simplifiedSymbol.substring(1);
	        }

	        return new Literal(simplifiedSymbol, negated);
	    }
		
		public boolean isComplementary(Literal literal2) {
			if(this.symbol.equals(literal2.symbol) && this.negated != literal2.negated) {
				return true;
			}
			return false;
		}
		
		public String toString() {
			if(negated) {
				return "~" + symbol;
			}
			else {
				return symbol;
			}
		}
	}
	
	private static class Clause{
		private Set<Literal> literals;
		
		private Clause() {
			literals = new HashSet<>();
		}
		
		private void addLiteral(Literal literal) {
			literals.add(literal);
		}
		
		private void addLiterals(Set<Literal> literals) {
			this.literals.addAll(literals);
		}
		
		private Set<Literal> getLiterals(){
			return literals;
		}
		
		private void removeNegations() { //remove unnecessary negations form clauses
			Set<Literal> simplifiedLiterals = new HashSet<>();

	        for (Literal literal : literals) {
	            Literal simplifiedLiteral = literal.simplify();
	            simplifiedLiterals.add(simplifiedLiteral);
	        }

	        literals = simplifiedLiterals;
		}
		
		public String toString() {
			String clause = "";
			int count = 0;
			for(Literal literal: literals) {
				clause += literal;
				count++;
				if(count < literals.size()) {
					clause += " v ";
				}
			}
			return clause;
		}
	}
	
	private static class ParseTreeNode{
		boolean isUnary; //either unary (true) OR binary (false)
		String sentence;
		String connective;
		List<ParseTreeNode> children;
		String side; //rhs lhs sub or orig
		
		private ParseTreeNode(boolean isUnary, String sentence, String connective, String side){
			this.isUnary = isUnary;
			this.sentence = sentence;
			this.connective = connective;
			this.children = new ArrayList<>();
			this.side = side;
		}
		
		public String toString() {
			if(isUnary) {
				if(connective.equals("symbol")) {
					return side + ": [" + sentence + "] Unary [" + connective + "]: ["
							+ sentence + "]";
				}
				return side + ": [" + sentence + "] Unary [" + connective + "]";
			}
			else {
				return side + ": [" + sentence + "] Binary [" + connective + "]";
			}
		}
		
	}
	
	private static class ParseTree{
		String sentence;
		ParseTreeNode root;
		
		public ParseTree(String sentence) {
			this.sentence = sentence;
		}
		
		private void parse() {
			root = parseSentence(sentence, "Orig");
		}

		private ParseTreeNode parseSentence(String sentence, String side) {
			ParseTreeNode treeNode = new ParseTreeNode(false, "", "", side);
			
			if(sentence.startsWith("(") && sentence.endsWith(")")) { //unary
				if(countParens(sentence) == 1) {
					treeNode = new ParseTreeNode(true, sentence, "()", side);
					sentence = sentence.substring(1, sentence.length()-1).trim();
					treeNode.children.add(parseSentence(sentence, "Sub"));
				}
				else {
					treeNode = parseBinaryParenthesis(sentence, side);
				}
			}
			else if(sentence.startsWith("~")) { //unary
				treeNode = new ParseTreeNode(true, sentence, "~", side);
				sentence = sentence.substring(1);
				treeNode.children.add(parseSentence(sentence, "Sub"));
			}
			else if(!sentence.contains("v") && !sentence.contains("^") && !sentence.contains("=>")
					&& !sentence.contains("<=>")){ //unary
				treeNode = new ParseTreeNode(true, sentence, "symbol", side);
			}
			
			else if(sentence.contains("v")){
				treeNode = parseBinary(sentence, "v", side);
			}
			else if(sentence.contains("^")){
				treeNode = parseBinary(sentence, "^", side);
			}
			else if(sentence.contains("<=>")){
				treeNode = parseBinary(sentence, "<=>", side);
			}
			else if(sentence.contains("=>")){
				treeNode = parseBinary(sentence, "=>", side);
			}
			return treeNode;
		}
		
		private int countParens(String sentence) {
			int count = 0;
			for(int i = 0; i < sentence.length(); i++) {
				if(sentence.charAt(i) == '(') {
					count++;
				}
			}
			return count;
		}
		
		private ParseTreeNode parseBinary(String sentence, String connective, String side) {
			ParseTreeNode treeNode = new ParseTreeNode(false, sentence, connective, side);
			int index = sentence.indexOf(connective);
			String lhs = sentence.substring(0, index);
			String rhs = sentence.substring(index + connective.length());
			
			treeNode.children.add(parseSentence(lhs, "LHS"));
			treeNode.children.add(parseSentence(rhs, "RHS"));
			return treeNode;
		}
		
		private ParseTreeNode parseBinaryParenthesis(String sentence, String side) {
			// case where it is binary sentence but starts and ends with parenthesis
			
			ParseTreeNode treeNode = new ParseTreeNode(false, "", "", side);
			int index = getConnectiveIndex(sentence); //outermost connective, for example v in p v (q^r)
			
			//check if the parenthesis are the outermost parenthesis, then this is unary
			if (index == -1 || (index > 0 && index < sentence.length() - 1 
					&& sentence.charAt(index - 1) == '(' && sentence.charAt(index + 1) == ')')) {		      
		        treeNode = new ParseTreeNode(true, sentence, "()", side);
		        sentence = sentence.substring(1, sentence.length() - 1).trim();
		        treeNode.children.add(parseSentence(sentence, "Sub"));
		    } 
			else {
				String connective = getConnective(sentence, index);
				
				treeNode = new ParseTreeNode(false, sentence, connective, side);
				
				String lhs = sentence.substring(0, index).trim();
				String rhs = sentence.substring(index + connective.length()).trim();
				
				treeNode.children.add(parseSentence(lhs, "LHS"));
				treeNode.children.add(parseSentence(rhs, "RHS"));
			
			}
			return treeNode;
		}
		
		private String getConnective(String sentence, int connectiveIndex) {
			int connectiveLength = 1;
		    char nextChar = sentence.charAt(connectiveIndex + connectiveLength);

		    while (isConnective(nextChar)) {
		        connectiveLength++;
		        nextChar = sentence.charAt(connectiveIndex + connectiveLength);
		    }
		    
		    return sentence.substring(connectiveIndex, connectiveIndex + connectiveLength);
		}
		
		private int getConnectiveIndex(String sentence) {
			int parensCount = 0;
			
			for(int i = 0; i < sentence.length(); i++) {
				char currChar = sentence.charAt(i);
				
				if(currChar == '(') {
					parensCount++;
				}
				else if(currChar == ')') {
					parensCount--;
				}
				else if(parensCount == 0 && isConnective(currChar)) {
					return i;
				}
			}
			
			return -1;
			
		}
		
		private boolean isConnective(char c) {
			if(c == 'v' || c == '^' || c == '=' || c == '<' || c =='>') {
				return true;
			}
			return false;
		}
		
		private void printParseTree() {
			printTreeNode(root);
			System.out.println();
		}
		
		private void printTreeNode(ParseTreeNode node) {
			System.out.print(node);
	        for (ParseTreeNode child : node.children) {
	            System.out.println();
	            printTreeNode(child);
	        }
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		String fileName = "";
		for(int i=0; i<args.length; i++) {
			fileName = args[i];
		}
		
		KnowledgeBase knowledgeBase = new KnowledgeBase();
		
		if(fileName!= "") { //read from file
			readFile(knowledgeBase, fileName);
		}
		else { //interactive mode
			interactiveMode(knowledgeBase);
		}
		
	}
	
	private static void readFile(KnowledgeBase knowledgeBase, String fileName) throws FileNotFoundException {
		File fileCommands = new File(fileName);
		Scanner scan = new Scanner(fileCommands);
		while(scan.hasNextLine()) {
			String command = scan.nextLine();
			if(command.isEmpty() || command.charAt(0) == ('#')) {
				continue;
			}
			System.out.println("> " + command);
			doCommands(command, knowledgeBase);
		}
		scan.close();
	}
	
	private static void interactiveMode(KnowledgeBase knowledgeBase) {
		System.out.printf("Welcome to the Knowledge Base!\nPlease TELL or ASK me anything!\n"
				+ "(type HELP for more information)\n> ");
		Scanner scan = new Scanner(System.in);
		String command = scan.nextLine();
		while(true) {
			doCommands(command, knowledgeBase);
			System.out.print("> ");
			command = scan.nextLine();
		}
	}
	
	private static void doCommands(String command, KnowledgeBase knowledgeBase) {
		String firstWord = command.split("\\s+")[0];
		String commandUpper = command.split("\\s+")[0].toUpperCase();
		if(commandUpper.contains("HELP")) {
			printCommands();
		}
		else if(commandUpper.contains("DONE") || commandUpper.contains("EXIT") || 
				commandUpper.contains("QUIT")) {
			System.out.println("Thank you for using the Knowledge Base!");
			System.exit(0);
		}
		else if(commandUpper.contains("TELLC")) {
			String clause = command.replaceAll(firstWord, "").replaceAll(" ", "").
					replaceAll("V", " v ").replaceAll("v", " v ");
			knowledgeBase.addClause(clause);
		}
		else if(commandUpper.contains("PRINT")) {
			for(Clause clause: knowledgeBase.clauses) {
				System.out.printf("(%s)\n", clause);
			}
			
		}
		else if(commandUpper.contains("ASK")) {
			String queryString = command.replaceAll(firstWord, "").replaceAll(" ", ""); 
			entails = resolution(knowledgeBase, queryString);
			if(entails) {
				System.out.printf("Yes, KB entails %s\n", queryString);
			}
			else {
				System.out.printf("No, KB does not entail %s\n", queryString);
			}
		}
		else if(commandUpper.contains("PROOF")) {
			String query = command.replaceAll(firstWord, "").replaceAll(" ", "");
			if(!entails) {
				if(resolution(knowledgeBase, query)) { //case where user wants proof before ASK
					System.out.println("Proof of: " + query);
					printProof(proof);
				}
				else {
					System.out.println("No proof exists");
				}
			}
			else {
				System.out.println("Proof of: " + query);
				printProof(proof);
			}
		}
		else if(commandUpper.contains("PARSE")) {
			String sentence = command.replaceAll(firstWord, "").replaceAll(" ", "");
			ParseTree parseTree = new ParseTree(sentence);
			parseTree.parse();
			parseTree.printParseTree();
		}
	}

	private static void printCommands() {
		System.out.printf("DONE, EXIT, QUIT - terminates the session\n"
				+ "TELLC <clause> - Adds the given <clause> to the knowledge base\n"
				+ "PRINT - Prints the clauses currently in the knowledge base\n"
				+ "ASK <query> - Determines if the knowledge base entails <query>\n"
				+ "PROOF <query> - Prints a proof of <query> from the knowledge base\n"
				+ "PARSE <sentence> - Prints the parse tree of the given <sentence> in propositional logic\n"
				+ "CNF <sentence> - Prints the conjunctive normal form representation of the given "
				+ "<sentence> in propositional logic\n"
				+ "TELL <sentence> - Adds the clauses in the CNF representation of <sentence> "
				+ "to the knowledge base\n");
	}
	
	//the resolution refutation method
	private static boolean resolution(KnowledgeBase kB, String query) { //needs to already be in CNF form
		Set<Clause> originalClauses = new HashSet<>(kB.clauses); //keep the original premises
			//user might ask several times!
		for(Clause clause: originalClauses) {
			proof.add(clause.toString() + "	[Premise]");
		}
		
		String negatedQuery = negate(query);
		kB.addClause(negatedQuery);
		
		proof.add(negatedQuery + "	[Negated Goal]");
		
		Set<Clause> newSet = new HashSet<Clause>();
		
		while(true) {
			Set<Clause[]> clausePairs = getClausePairs(kB.clauses);
			
			for(Clause[] clausePair: clausePairs) {
				Set<Clause> resolvents = resolve(clausePair[0], clausePair[1]);
				
				for (Clause resolvent : resolvents) {
				    if (resolvent.getLiterals().isEmpty()) {
				    	
				    	proof.add("()	[Resolution on " + resolvedLiteral + ": ]");
				    	kB.clauses.clear();
			            kB.clauses.addAll(originalClauses);
				        return true;
				    }
				    else {
				    	proof.add(resolvent + "	[Resolution on " + resolvedLiteral + ": ]");
				    }
				}
				newSet = unionClauses(newSet, resolvents);
			}
			
			if(kB.clauses.containsAll(newSet)) { //new set is a subset of clauses
				kB.clauses.clear();
	            kB.clauses.addAll(originalClauses);
				return false;
			}
			
			kB.clauses.addAll(newSet);
			
		}
	}
	
	private static Set<Clause> unionClauses(Set<Clause> newSet, Set<Clause> resolvents) {
		for(Clause resolvent: resolvents) {
			String resolventString = resolvent.toString();
			boolean containsResolvent = false;

		    for (Clause existingClause : newSet) {
		        if (resolventString.equals(existingClause.toString())) {
		            containsResolvent = true;
		            break;
		        }
		    }

		    if (!containsResolvent) {
		        newSet.add(resolvent);
		    }
		}
		return newSet;
	}
	
	private static String negate(String query) {
		return "~" + query;
	}
	
	private static Set<Clause[]> getClausePairs(Set<Clause> clauses){
		Set<Clause[]> clausePairs = new HashSet<>();
		
		List<Clause> clausesList = new ArrayList<>(clauses);

	    int size = clausesList.size();
	    for (int i = 0; i < size; i++) {
	        for (int j = i + 1; j < size; j++) {
	            Clause clause1 = clausesList.get(i);
	            Clause clause2 = clausesList.get(j);
	            clausePairs.add(new Clause[] {clause1, clause2});
	        }
	    }
	    
		return clausePairs;
	}
	
	private static Set<Clause> resolve(Clause clause1, Clause clause2){
		Set<Clause> resolvents = new HashSet<Clause>();
		
		clause1.removeNegations();
		clause2.removeNegations();
		
		for(Literal literal1: clause1.getLiterals()) {
			for(Literal literal2: clause2.getLiterals()) {
				if(literal1.isComplementary(literal2)) { 
					Set<Literal> combinedLiterals = combineLiterals(clause1, clause2, literal1, literal2);
					Clause resolvent = new Clause();
					resolvent.addLiterals(combinedLiterals); 
					resolvents.add(resolvent);
					resolvedLiteral = literal1.symbol;
				}
			}
		}
		
		return resolvents;
	}

	
	private static Set<Literal> combineLiterals(Clause clause1,
			Clause clause2, Literal literal1, Literal literal2){
		Set<Literal> combinedLiterals = new HashSet<>();
		
		for(Literal literal: clause1.getLiterals()) {
			if(!literal.equals(literal1)) { //do not add the complementary literals to new clause!
				combinedLiterals.add(literal);
			}
		}
		
		for(Literal literal: clause2.getLiterals()) {
			if(!literal.equals(literal2)) {
				combinedLiterals.add(literal);
			}
		}
		
		return combinedLiterals;
	}
	
	private static void printProof(List<String> proof) {
		int count = 1;
		for(String step: proof) {
			System.out.println(" " + count + ". " + step);
			count++;
		}
		proof.clear(); //reset the proof, user may want to ask for proof for a different query
	}
}
